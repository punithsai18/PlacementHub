const sql = require('mssql');
const { CosmosClient } = require('@azure/cosmos');

// Azure SQL configuration
const sqlConfig = {
  user: process.env.AZURE_SQL_USER,
  password: process.env.AZURE_SQL_PASSWORD,
  database: process.env.AZURE_SQL_DATABASE,
  server: process.env.AZURE_SQL_SERVER,
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  },
  options: {
    encrypt: true,
    trustServerCertificate: false
  }
};

let sqlPool = null;

async function getSqlPool() {
  if (!sqlPool) {
    if (!process.env.AZURE_SQL_SERVER) {
      throw new Error('Azure SQL environment variables are not configured. Please set AZURE_SQL_SERVER, AZURE_SQL_USER, AZURE_SQL_PASSWORD, AZURE_SQL_DATABASE.');
    }
    try {
      sqlPool = await sql.connect(sqlConfig);
      console.log('Connected to Azure SQL Database');
    } catch (err) {
      console.error('Azure SQL connection failed:', err.message);
      throw err;
    }
  }
  return sqlPool;
}

// Cosmos DB configuration
let cosmosClient = null;
let cosmosDb = null;

function getCosmosClient() {
  if (!cosmosClient) {
    if (!process.env.COSMOS_DB_ENDPOINT || !process.env.COSMOS_DB_KEY) {
      throw new Error('Cosmos DB environment variables are not configured. Please set COSMOS_DB_ENDPOINT and COSMOS_DB_KEY.');
    }
    cosmosClient = new CosmosClient({
      endpoint: process.env.COSMOS_DB_ENDPOINT,
      key: process.env.COSMOS_DB_KEY
    });
  }
  return cosmosClient;
}

async function getCosmosDb() {
  if (!cosmosDb) {
    const client = getCosmosClient();
    const dbName = process.env.COSMOS_DB_NAME || 'placementhub';
    const { database } = await client.databases.createIfNotExists({ id: dbName });
    cosmosDb = database;
    console.log('Connected to Cosmos DB');
  }
  return cosmosDb;
}

module.exports = { getSqlPool, getCosmosDb, sql };
