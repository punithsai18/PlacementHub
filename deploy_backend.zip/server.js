require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const studentRoutes = require('./src/routes/students');
const companyRoutes = require('./src/routes/companies');
const chatRoutes = require('./src/routes/chat');
const placementRoutes = require('./src/routes/placements');

const app = express();
const PORT = process.env.PORT || 5000;

// Trust proxy for Azure App Service load balancer
app.set('trust proxy', 1);

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Global rate limiter: 100 requests per 15 minutes per IP
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip ? req.ip.replace(/:\d+$/, '') : req.socket.remoteAddress,
  message: { error: 'Too many requests, please try again later.' }
});

// Stricter limiter for auth endpoints: 10 per 15 minutes per IP
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip ? req.ip.replace(/:\d+$/, '') : req.socket.remoteAddress,
  message: { error: 'Too many authentication attempts, please try again later.' }
});

app.use('/api/', globalLimiter);
app.use('/api/students/login', authLimiter);
app.use('/api/students/register', authLimiter);
app.use('/api/companies/login', authLimiter);
app.use('/api/companies/register', authLimiter);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), service: 'PlacementHub API' });
});

// Routes
app.use('/api/students', studentRoutes);
app.use('/api/companies', companyRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/placements', placementRoutes);

// Global error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

app.listen(PORT, () => {
  console.log(`PlacementHub API running on port ${PORT}`);
});

module.exports = app;
